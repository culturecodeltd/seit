self.__BUILD_MANIFEST = {
  "/": [
    "static/chunks/04be7206f3777a74.js"
  ],
  "/404": [
    "static/chunks/ba8bab199b275a8a.js"
  ],
  "/_error": [
    "static/chunks/19f793134e5c7868.js"
  ],
  "/brand-assets": [
    "static/chunks/84592609262caa82.js"
  ],
  "/contact": [
    "static/chunks/296f5ea08031eb6b.js"
  ],
  "/content": [
    "static/chunks/0dc8d12f272e87d5.js"
  ],
  "/disclosures": [
    "static/chunks/3193bc11e1dbf57f.js"
  ],
  "/error": [
    "static/chunks/7a1be278e604b966.js"
  ],
  "/investments": [
    "static/chunks/a968f137c0a21ccc.js"
  ],
  "/privacy-policy": [
    "static/chunks/763ed2ffcb0e5cf0.js"
  ],
  "/team": [
    "static/chunks/3d7791176215124a.js"
  ],
  "/team/[slug]": [
    "static/chunks/034f8da164cb8096.js"
  ],
  "/terms-of-use": [
    "static/chunks/edc4832300a6ada4.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/",
    "/404",
    "/_app",
    "/_error",
    "/brand-assets",
    "/contact",
    "/content",
    "/disclosures",
    "/error",
    "/investments",
    "/privacy-policy",
    "/team",
    "/team/[slug]",
    "/terms-of-use"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()