__turbopack_load_page_chunks__("/contact", [
  "static/chunks/07d4c45cc59f503f.js",
  "static/chunks/bf6653fbb72adf1a.js",
  "static/chunks/33199af12bee9778.js",
  "static/chunks/3152e733d2e5fc48.js",
  "static/chunks/turbopack-27eedf6cc7ecbf1b.js"
])
