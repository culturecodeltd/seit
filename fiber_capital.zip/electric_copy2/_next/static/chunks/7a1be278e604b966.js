__turbopack_load_page_chunks__("/error", [
  "static/chunks/3943f0ac20a91cb2.js",
  "static/chunks/bf6653fbb72adf1a.js",
  "static/chunks/33199af12bee9778.js",
  "static/chunks/3152e733d2e5fc48.js",
  "static/chunks/turbopack-2367b1ac3aa277ed.js"
])
