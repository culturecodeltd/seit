__turbopack_load_page_chunks__("/investments", [
  "static/chunks/c885bbf78a6c6f36.js",
  "static/chunks/bf6653fbb72adf1a.js",
  "static/chunks/3152e733d2e5fc48.js",
  "static/chunks/33199af12bee9778.js",
  "static/chunks/turbopack-ee10a7f466591908.js"
])
