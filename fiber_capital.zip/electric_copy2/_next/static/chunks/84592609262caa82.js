__turbopack_load_page_chunks__("/brand-assets", [
  "static/chunks/ca0a5bcb9df6f6fc.js",
  "static/chunks/bf6653fbb72adf1a.js",
  "static/chunks/33199af12bee9778.js",
  "static/chunks/3152e733d2e5fc48.js",
  "static/chunks/turbopack-9bb0725b5972751c.js"
])
