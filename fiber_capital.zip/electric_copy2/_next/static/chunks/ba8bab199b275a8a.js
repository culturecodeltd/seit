__turbopack_load_page_chunks__("/404", [
  "static/chunks/52e7edacd373a253.js",
  "static/chunks/bf6653fbb72adf1a.js",
  "static/chunks/33199af12bee9778.js",
  "static/chunks/3152e733d2e5fc48.js",
  "static/chunks/turbopack-5064277d54bb353f.js"
])
