__turbopack_load_page_chunks__("/team", [
  "static/chunks/bf6653fbb72adf1a.js",
  "static/chunks/151188436d39c155.js",
  "static/chunks/3152e733d2e5fc48.js",
  "static/chunks/33199af12bee9778.js",
  "static/chunks/turbopack-77486d585cbd0303.js"
])
