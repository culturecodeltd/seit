__turbopack_load_page_chunks__("/", [
  "static/chunks/bf6653fbb72adf1a.js",
  "static/chunks/e161c71d09095703.js",
  "static/chunks/c8ac0f365de587ec.js",
  "static/chunks/3152e733d2e5fc48.js",
  "static/chunks/33199af12bee9778.js",
  "static/chunks/turbopack-ef99c531c6405091.js"
])
