__turbopack_load_page_chunks__("/_error", [
  "static/chunks/c15dc54408c1631a.js",
  "static/chunks/bf6653fbb72adf1a.js",
  "static/chunks/3152e733d2e5fc48.js",
  "static/chunks/33199af12bee9778.js",
  "static/chunks/turbopack-511336fc3cf87f1e.js"
])
