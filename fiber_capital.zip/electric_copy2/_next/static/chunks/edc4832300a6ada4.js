__turbopack_load_page_chunks__("/terms-of-use", [
  "static/chunks/9ffe69f996ca490c.js",
  "static/chunks/bf6653fbb72adf1a.js",
  "static/chunks/33199af12bee9778.js",
  "static/chunks/3152e733d2e5fc48.js",
  "static/chunks/turbopack-b86610cd0f512e0d.js"
])
