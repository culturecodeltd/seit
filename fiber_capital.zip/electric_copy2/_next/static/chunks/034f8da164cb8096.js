__turbopack_load_page_chunks__("/team/[slug]", [
  "static/chunks/8cbf40d6b4560070.js",
  "static/chunks/bf6653fbb72adf1a.js",
  "static/chunks/3152e733d2e5fc48.js",
  "static/chunks/33199af12bee9778.js",
  "static/chunks/turbopack-7e4b68de3863e5ab.js"
])
