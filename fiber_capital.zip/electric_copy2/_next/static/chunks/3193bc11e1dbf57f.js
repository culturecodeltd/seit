__turbopack_load_page_chunks__("/disclosures", [
  "static/chunks/3ca49532f26c91eb.js",
  "static/chunks/bf6653fbb72adf1a.js",
  "static/chunks/33199af12bee9778.js",
  "static/chunks/3152e733d2e5fc48.js",
  "static/chunks/turbopack-b732db1d2b4b2f02.js"
])
