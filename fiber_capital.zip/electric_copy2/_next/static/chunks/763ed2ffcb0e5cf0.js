__turbopack_load_page_chunks__("/privacy-policy", [
  "static/chunks/47dbe58b010d1bad.js",
  "static/chunks/bf6653fbb72adf1a.js",
  "static/chunks/33199af12bee9778.js",
  "static/chunks/3152e733d2e5fc48.js",
  "static/chunks/turbopack-f42dc5276ae0053b.js"
])
