__turbopack_load_page_chunks__("/content", [
  "static/chunks/bf6653fbb72adf1a.js",
  "static/chunks/cdcf02568e022cce.js",
  "static/chunks/33199af12bee9778.js",
  "static/chunks/3152e733d2e5fc48.js",
  "static/chunks/turbopack-7d845cabcfd5cc62.js"
])
